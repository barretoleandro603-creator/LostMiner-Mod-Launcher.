# LostMiner Mod Launcher (projeto Android)

Launcher Android simples para organizar arquivos ZIP e imagens PNG/JPG, ativar/desativar itens na lista, remover itens e abrir o LostMiner instalado.

## Limites importantes
- Este aplicativo guarda referências aos arquivos escolhidos pelo seletor do Android; não extrai nem instala pacotes dentro do LostMiner.
- A caixa “Ativado no launcher” controla apenas a organização da lista. Ela não ativa mods no jogo.
- A integração real com mods depende de uma API, pasta de mods ou formato documentado pelo LostMiner. Não foi confirmada uma interface pública para isso.

## Gerar APK
O ambiente em que este projeto foi preparado não tem Android SDK/Gradle instalado, então o APK não foi compilado aqui.

O workflow `.github/workflows/build-apk.yml` compila automaticamente um APK de teste quando o projeto é enviado para um repositório GitHub:
1. Crie um repositório GitHub e envie o conteúdo desta pasta.
2. Abra a aba **Actions**.
3. Selecione **Build Android APK** e execute **Run workflow** (ou aguarde o build após enviar para `main`).
4. Quando terminar, abra a execução e baixe o artefato `LostMiner-Mod-Launcher-APK`.
5. Dentro do ZIP do artefato estará `app-debug.apk`.

Requisitos: Android Studio/Gradle Plugin 8.6.1, Gradle 8.7 e JDK 17.


Correção do botão Abrir LostMiner: o launcher agora procura diretamente o pacote Android `com.fsilva.marcelo.lostminer`.

package com.example.lostminerlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 41;
    private final ArrayList<Item> items = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout list;
    private TextView empty;
    private int bg = Color.rgb(16,21,16), panel = Color.rgb(29,39,29), green = Color.rgb(121,214,107), white = Color.WHITE;

    static class Item {
        String uri, name, kind; boolean enabled;
        Item(String u, String n, String k, boolean e) { uri=u; name=n; kind=k; enabled=e; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        loadItems();
        buildScreen();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button makeButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.BLACK); b.setTextSize(14); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return b;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(12)); root.setBackgroundColor(bg);
        TextView title = text("LOSTMINER", 28, green); title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        TextView sub = text("MOD LAUNCHER  •  2D", 13, Color.LTGRAY); sub.setPadding(0,0,0,dp(16)); root.addView(sub);

        Button launch = makeButton("▶  ABRIR LOSTMINER");
        root.addView(launch, new LinearLayout.LayoutParams(-1, dp(52)));
        launch.setOnClickListener(v -> launchLostMiner());

        Button add = makeButton("＋  IMPORTAR ZIP / PNG / JPG");
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(48)); ap.topMargin=dp(10); root.addView(add, ap);
        add.setOnClickListener(v -> pickFile());

        TextView heading = text("MEUS ARQUIVOS", 17, white); heading.setTypeface(null, Typeface.BOLD); heading.setPadding(0,dp(20),0,dp(8)); root.addView(heading);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        empty = text("Nenhum arquivo importado ainda.\nUse o botão acima para adicionar ZIPs ou imagens.", 14, Color.LTGRAY); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(12),dp(30),dp(12),dp(30));

        TextView note = text("Aviso: o launcher organiza seus arquivos e abre o jogo. A ativação aqui não injeta mods no LostMiner; isso depende de suporte do próprio jogo.", 11, Color.GRAY);
        note.setPadding(0,dp(10),0,0); root.addView(note);
        setContentView(root); renderList();
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip","application/x-zip-compressed","image/png","image/jpeg"});
        startActivityForResult(i, PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FILE && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri u=data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            String name=getName(u); String lower=name.toLowerCase();
            String kind=lower.endsWith(".zip")?"Pacote ZIP":(lower.endsWith(".png")||lower.endsWith(".jpg")||lower.endsWith(".jpeg"))?"Imagem / skin":"Arquivo";
            if(!lower.endsWith(".zip")&&!lower.endsWith(".png")&&!lower.endsWith(".jpg")&&!lower.endsWith(".jpeg")) { Toast.makeText(this,"Escolha um arquivo ZIP, PNG ou JPG.",Toast.LENGTH_LONG).show(); return; }
            for(Item it:items) if(it.uri.equals(u.toString())) { Toast.makeText(this,"Esse arquivo já foi importado.",Toast.LENGTH_SHORT).show(); return; }
            items.add(new Item(u.toString(),name,kind,true)); saveItems(); renderList();
            Toast.makeText(this,"Arquivo adicionado ao launcher.",Toast.LENGTH_SHORT).show();
        }
    }

    private String getName(Uri uri) {
        String result="arquivo";
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)) { if(c!=null && c.moveToFirst()) { int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(ix>=0) result=c.getString(ix); } } catch(Exception ignored) {}
        return result;
    }

    private void renderList() {
        if(list==null) return; list.removeAllViews();
        if(items.isEmpty()) { list.addView(empty); return; }
        for(int index=0; index<items.size(); index++) {
            final int pos=index; Item item=items.get(index);
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12),dp(8),dp(12),dp(8)); card.setBackgroundTintList(null); card.setBackgroundColor(panel);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(8); list.addView(card,cp);
            TextView name=text(item.name,15,white); name.setTypeface(null,Typeface.BOLD); card.addView(name);
            TextView kind=text(item.kind,12,Color.LTGRAY); card.addView(kind);
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); card.addView(row);
            CheckBox check=new CheckBox(this); check.setText("Ativado no launcher"); check.setTextColor(white); check.setButtonTintList(android.content.res.ColorStateList.valueOf(green)); check.setChecked(item.enabled); row.addView(check,new LinearLayout.LayoutParams(0,dp(48),1));
            check.setOnCheckedChangeListener((v,checked)->{ items.get(pos).enabled=checked; saveItems(); });
            Button remove=new Button(this); remove.setText("Remover"); remove.setTextSize(12); remove.setAllCaps(false); remove.setTextColor(Color.WHITE); remove.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(105,55,55))); row.addView(remove);
            remove.setOnClickListener(v->{ items.remove(pos); saveItems(); renderList(); });
        }
    }

    private void launchLostMiner() {
        PackageManager pm=getPackageManager();
        try {
            for(ApplicationInfo app:pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                String label=pm.getApplicationLabel(app).toString();
                if(label.toLowerCase().contains("lostminer")) {
                    Intent launch=pm.getLaunchIntentForPackage(app.packageName);
                    if(launch!=null) { startActivity(launch); return; }
                }
            }
        } catch(Exception ignored) {}
        Toast.makeText(this,"Não encontrei o LostMiner instalado. Instale o jogo primeiro.",Toast.LENGTH_LONG).show();
    }

    private void loadItems() {
        Set<String> saved=prefs.getStringSet("items",new HashSet<>());
        for(String s:saved) { String[] p=s.split("\\|",4); if(p.length==4) items.add(new Item(p[0],p[1],p[2],Boolean.parseBoolean(p[3]))); }
    }
    private void saveItems() {
        Set<String> saved=new HashSet<>();
        for(Item it:items) saved.add(it.uri.replace("|","%7C")+"|"+it.name.replace("|"," ")+"|"+it.kind.replace("|"," ")+"|"+it.enabled);
        prefs.edit().putStringSet("items",saved).apply();
    }
}
